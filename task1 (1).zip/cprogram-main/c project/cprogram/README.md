# cprogram
I This repository contains the source code for an authentication system implemented in C. It provides user registration and login functionality, allowing users to sign up with their full name, email, contact number, and password. The system stores user data securely and verifies login credentials to grant access to registered users.
